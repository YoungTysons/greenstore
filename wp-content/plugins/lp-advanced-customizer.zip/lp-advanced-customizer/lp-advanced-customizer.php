<?php
/**
 * Plugin Name: LearnPress Advanced Customizer
 * Description: Tùy biến thông báo, thống kê chi tiết khóa học và giao diện LearnPress.
 * Version: 1.1
 * Author: [Tên của bạn]
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * YÊU CẦU 1: Hiển thị thông báo Notification Bar
 * Sử dụng hook 'wp_body_open' để hiển thị ngay đầu trang hoặc 'loop-page-title' của LP
 */
add_action( 'wp_body_open', 'lpc_notification_bar' );
function lpc_notification_bar() {
    // Chỉ hiển thị trong trang khóa học của LearnPress
    if ( is_singular( 'lp_course' ) ) {
        echo '<div class="lpc-notification-bar" style="background: #333; color: #fff; text-align: center; padding: 10px; font-weight: bold;">';
        
        if ( is_user_logged_in() ) {
            $current_user = wp_get_current_user();
            echo "Chào " . esc_html( $current_user->display_name ) . ", bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?";
        } else {
            echo "Đăng nhập để lưu tiến độ học tập!";
        }
        
        echo '</div>';
    }
}

/**
 * YÊU CẦU 2: Shortcode thống kê chi tiết [lp_course_info id="xxx"]
 */
add_shortcode( 'lp_course_info', 'lpc_course_info_shortcode' );
function lpc_course_info_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id' => get_the_ID(), // Mặc định lấy ID bài viết hiện tại nếu không nhập
    ), $atts );

    $course_id = $atts['id'];
    $course = learn_press_get_course( $course_id );

    if ( ! $course ) return "Không tìm thấy khóa học.";

    // 1. Số lượng bài học
    $lessons = $course->get_items( 'lp_lesson' );
    $count_lessons = count( $lessons );

    // 2. Tổng thời gian (Duration)
    $duration = $course->get_data( 'duration' );

    // 3. Trạng thái người dùng
    $user = learn_press_get_current_user();
    $status = "Chưa đăng ký";
    
    if ( $user->has_finished_course( $course_id ) ) {
        $status = "Đã hoàn thành ✅";
    } elseif ( $user->has_enrolled_course( $course_id ) ) {
        $status = "Đã đăng ký 📖";
    }

    $output = "<div class='lpc-course-box' style='border:2px solid orange; padding:15px; margin:10px 0;'>";
    $output .= "<h4>Thông tin khóa học: " . get_the_title($course_id) . "</h4>";
    $output .= "<ul>";
    $output .= "<li>Số bài học: <b>$count_lessons</b></li>";
    $output .= "<li>Thời gian dự kiến: <b>$duration</b></li>";
    $output .= "<li>Trạng thái của bạn: <span style='color:green;'>$status</span></li>";
    $output .= "</ul>";
    $output .= "</div>";

    return $output;
}

/**
 * YÊU CẦU 3: Tùy biến Style (Custom CSS)
 * Đổi màu nút Enroll và Finish sang màu Cam
 */
add_action( 'wp_head', 'lpc_custom_styles' );
function lpc_custom_styles() {
    ?>
    <style>
        /* Nút Enroll (Ghi danh) */
        .lp-course-buttons .button-enroll-course, 
        .lp-course-buttons .lp-button {
            background-color: #ff8c00 !important; /* Màu cam */
            border-color: #ff8c00 !important;
            color: #fff !important;
        }

        /* Nút Finish Course (Hoàn thành) */
        .lp-button.button-finish-course {
            background-color: #2ecc71 !important; /* Màu xanh lá */
            border-color: #2ecc71 !important;
        }
        
        .lpc-notification-bar { margin-bottom: 5px; }
    </style>
    <?php
}